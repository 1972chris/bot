﻿namespace WebHook.Model
{
    public class HookResponse
    {
        public string Result { get; set; }
    }
}
