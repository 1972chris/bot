﻿namespace Install
{
    public class InstallationTokenParameters
    {
        public int AppId { get; set; }

        public string AccessTokensUrl { get; set; }
    }
}
