﻿namespace Common
{
    public static class KnownScheduleSettings
    {
        public const string Daily = "daily";

        public const string Weekly = "weekly";

        public const string Monthly = "monthly";
    }
}
