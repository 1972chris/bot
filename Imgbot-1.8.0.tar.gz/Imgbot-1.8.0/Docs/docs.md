Here you will find all the reference information on ImgBot. Anything you need to know about how it works or how to contribute can be found below.

ImgBot <3 contributions.

All of the ImgBot documentation is checked into [GitHub](https://github.com/dabutvin/ImgBot/tree/master/Docs). If there is any issue or something that is missing please feel free to open an issue and/or pull request to get it fixed up.
