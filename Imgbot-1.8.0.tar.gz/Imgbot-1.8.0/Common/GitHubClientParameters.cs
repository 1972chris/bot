﻿namespace Common
{
    public class GitHubClientParameters
    {
        public string RepoOwner { get; set; }

        public string RepoName { get; set; }

        public string Password { get; set; }
    }
}
