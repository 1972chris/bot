export const settings = {
  authhost: 'https://auth.imgbot.net'
}